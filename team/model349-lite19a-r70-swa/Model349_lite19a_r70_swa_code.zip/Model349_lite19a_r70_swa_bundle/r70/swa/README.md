# lite19a_r70 + SWA: train70 B4 1개로 fold 앙상블 효과를 되찾을 수 있는지 (팀원 실행용)

## 배경 (anacnu에서 측정, valid20 최종 점수, 공개판 설정 그대로)

| R의 B4 구성 | valid20 | lite19a 대비 |
|---|---:|---:|
| lite19a (valid로 고른 fold 6개) | 80.5236 | — |
| fold 4개 전부 평균 (고르지 않음) | 80.3876 | −0.136 |
| fold 1개만 (fold1~4 각각) | 79.91 / 80.02 / 80.11 / 79.99 | 평균 −0.515 |
| train70 모델 1개 (팀원 B4 3개, seed 0, 21,000회) | 79.9886 | −0.535 |

- fold를 valid로 고른 편향은 약 0.14입니다.
- r70이 잃는 0.54는 대부분 "모델 1개 vs 여러 개 평균"의 차이입니다. train70 모델 1개는 fold 모델 1개와 점수가 거의 같았습니다.
- 그래서 **모델 수를 늘리지 않고 평균 효과를 되찾는 방법**으로 SWA를 시험합니다.

## 하는 일
1. 이미 받은 train70 B4 3개(322/326/329)에서 이어서 학습합니다.
   - 학습량: **4,000회**
   - 학습률: 1e-4로 고정
   - 500회마다 가중치를 평균합니다(스냅샷 8개).
   - 끝나면 BatchNorm 통계를 train 배치 300개로 다시 계산해 `last.pt`로 저장합니다.
   - 데이터, crop, 증강, 손실, AdamW는 원래 B4 학습 코드와 같습니다.
   - valid는 읽지 않습니다. SWA 설정값은 결과를 보기 전에 정했고, valid로 고르지 않습니다.
2. `run_r70.sh`로 valid20(채점)과 test10을 추론합니다.
   - SWA판 lite19a_r70과 lite19a를 같은 나머지 가중치로 돌려서 짝 비교합니다.
   - 원래 train70 B4(plain)로 만든 lite19a_r70도 같이 돌려 기준으로 씁니다.

## 실행
```sh
# PLAIN_B4: 받은 zip 3개를 풀어 둔 폴더 (Model349_lite20_r70_B4_{322,326,329}/{last.pt,args.json})
bash r70/run_swa.sh /path/DATA /path/WEIGHTS/R /path/WEIGHTS/assets /path/PLAIN_B4 /path/runs/r70_swa 0,1,2
```
- `DATA`: `train/{images,masks}`(70장), `valid/{images,masks}`(20장), `test/images`.
- `WEIGHTS/R`, `WEIGHTS/assets`: 공개 가중치입니다. lite19a에서 쓰는 것과 같습니다.
- GPU 목록의 GPU마다 B4 하나씩 동시에 학습합니다. GPU는 시작할 때만 비어 있는지 확인합니다.
- 끝난 단계는 건너뛰므로, 중간에 끊기면 같은 명령으로 이어서 돌리면 됩니다.

## 시간 (P100 기준 추정)
- SWA 학습 1개는 4,000회라 약 1.2시간입니다(21,000회 약 6시간 기준). GPU 3장이면 약 1.2시간입니다.
- 추론은 (SWA, plain) × (lite19a_r70, lite19a) × (valid, test)라 약 2시간입니다.

## 결과
- `OUT/swa/summary.txt`, `OUT/plain/summary.txt`에 다음이 들어 있습니다.
  - valid20 두 점수와 그 차이
  - 시편 단위 bootstrap 95% 구간
  - 좋아진/나빠진 장수, 가장 나빠진 이미지
  - test10 마스크 차이
- 보고할 것: 두 summary 파일, `OUT/swa/b4_full70/*/train.log`의 마지막 줄

## 판단 기준 (결과를 보기 전에 정함)
- **기준점은 fold 4개 전부 평균 80.39**입니다(선택 편향이 없는 비교 대상).
- SWA판이 plain(79.99)보다 오르고 80.39에 가까우면, 모델 수를 늘리지 않고 fold를 없앨 수 있다는 근거가 됩니다.
- SWA판이 plain과 비슷하면, SWA로는 fold 앙상블 효과를 되찾을 수 없다는 뜻입니다. 다음 후보는 앙상블 증류입니다.

## 바뀐 코드
- 새 파일: `r70/swa/train_swa.py`. `train_route/experiments/model326_hybrid_fullstats/KoMaP/train.py`를 복사해서 SWA 단계만 추가했습니다.
  - 322(gray3/imagenet)도 이 코드로 학습합니다. 326 코드는 322 코드에 기능을 더한 것이라, gray3/imagenet 설정에서는 똑같이 동작합니다.
- 새 파일: `r70/run_swa.sh`.
- 기존 파일은 바꾸지 않았습니다.
