#!/usr/bin/env bash
# lite19a_r70 with SWA versions of the 3 train70 B4 (322/326/329), plus the plain train70 B4 as reference.
#   bash r70/run_swa.sh DATA R_WEIGHTS ASSETS PLAIN_B4 OUT [GPUS e.g. 0,1,2]
# PLAIN_B4 : folder holding the 3 finished train70 B4 runs, each with last.pt + args.json, named either
#            Model349_lite20_r70_B4_{322,326,329} (the shared zips) or <B4 dir>_full70 (r70/train_r70.sh output)
# OUT      : OUT/swa/b4_full70/<B4 dir>_full70/{last.pt,args.json,train.log}  then  OUT/swa/summary.txt, OUT/plain/summary.txt
# SWA (fixed in advance, never tuned on valid): continue each model 4,000 iterations at constant lr 1e-4 on train70,
# average the weights every 500 iterations (8 snapshots), re-estimate BatchNorm statistics on 300 training batches.
# Then run_r70.sh predicts valid20/test10 with lite19a_r70 (B4 = SWA models) and lite19a on the same other weights.
set -euo pipefail
DATA=$(cd "$1" && pwd); RW=$(cd "$2" && pwd); AS=$(cd "$3" && pwd); PLAIN=$(cd "$4" && pwd); OUT=$5; GPUS=${6:-0}
HERE=$(cd "$(dirname "$0")/.." && pwd); PY=${PYTHON:-python}; CODE=$HERE/train_route/experiments/model326_hybrid_fullstats/KoMaP
SWA_ITERS=${SWA_ITERS:-4000}; SWA_LR=${SWA_LR:-1e-4}; SWA_EVERY=${SWA_EVERY:-500}; BN_BATCHES=${BN_BATCHES:-300}
mkdir -p "$OUT"; OUT=$(cd "$OUT" && pwd); IFS=, read -ra G <<< "$GPUS"
declare -A DIR=([322]=model322_team_b4_group_oof [326]=model326_hybrid_fullstats_group_oof [329]=model329_fullstats_width4000_uniform_group_oof)
src(){ local m=$1; for d in "$PLAIN/Model349_lite20_r70_B4_$m" "$PLAIN/${DIR[$m]}_full70"; do [[ -f $d/last.pt && -f $d/args.json ]] && { echo "$d"; return; }; done
  echo "missing train70 B4 $m under $PLAIN" >&2; exit 2; }
# plain reference: links to the given models
mkdir -p "$OUT/plain/b4_full70"; for m in 322 326 329; do ln -sfn "$(src $m)" "$OUT/plain/b4_full70/${DIR[$m]}_full70"; done
# start-only idle check
for g in "${G[@]}"; do u=$(nvidia-smi -i "$g" --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)
  IFS=', ' read -r mem util <<< "$u"; (( mem <= 64 && util == 0 )) || { echo "GPU $g busy before start ($u)"; exit 2; }; done
swa_one(){ local gpu=$1 m=$2 s run; s=$(src "$m"); run=$OUT/swa/b4_full70/${DIR[$m]}_full70
  [[ -f $run/last.pt ]] && { echo "skip SWA $m (done)"; return; }; mkdir -p "$run"
  read -r norm input scale tw sample <<< "$("$PY" -c "import json,sys;a=json.load(open(sys.argv[1]));print(a['norm'],a['input'],a['scale'],a['target_width'],a['sample'])" "$s/args.json")"
  echo "[$(date +%T)] SWA $m on GPU $gpu ($norm $input scale=$scale tw=$tw $sample)"
  ( cd "$CODE" && CUDA_VISIBLE_DEVICES=$gpu PYTHONPATH="$CODE" PYTHONUNBUFFERED=1 OMP_NUM_THREADS=4 "$PY" -u "$HERE/r70/swa/train_swa.py" --data "$DATA" --train_splits train \
      --out "$run" --arch unet --encoder efficientnet-b4 --norm "$norm" --input "$input" --crop 1536 --scale "$scale" --target_width "$tw" \
      --sample "$sample" --bs 2 --wd 1e-2 --dice_w 1 --cldice_w 0 --seed 0 --workers 4 --deterministic_workers \
      --init_checkpoint "$s/last.pt" --swa_iters "$SWA_ITERS" --swa_lr "$SWA_LR" --swa_every "$SWA_EVERY" --bn_batches "$BN_BATCHES" ) > "$run/train.log" 2>&1
  grep -q "SWA done" "$run/train.log" || { echo "FAIL SWA $m (see $run/train.log)"; return 1; }; echo "[$(date +%T)] done SWA $m"; }
pids=(); MS=(322 326 329)
for gi in "${!G[@]}"; do ( for mi in "${!MS[@]}"; do (( mi % ${#G[@]} == gi )) && { swa_one "${G[$gi]}" "${MS[$mi]}" || exit 1; }; done; true ) & pids+=($!); done
fail=0; for p in "${pids[@]}"; do wait "$p" || fail=1; done; (( fail == 0 )) || { echo "SWA training failed"; exit 1; }
# evaluate: run_r70.sh skips training when all 3 models exist
for v in swa plain; do BASE=lite19a bash "$HERE/run_r70.sh" 0 "$DATA" "$RW" "$AS" "$OUT/$v" "$GPUS"; done
echo "== SWA";   cat "$OUT/swa/summary.txt"
echo "== plain"; cat "$OUT/plain/summary.txt"
echo SWA_ALL_DONE
