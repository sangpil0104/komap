#!/usr/bin/env bash
# Score fixed R-pruning candidates on every seed's lite20 weights (no training, no re-selection per seed).
#   bash seed_compare/run_seed_variants.sh DATA OUT GPU SEED_DIR [SEED_DIR ...]
# SEED_DIR : one seed's lite20 weights, either  SEED_DIR/R/weights + SEED_DIR/assets  (run_retrain.sh output)
#            or  SEED_DIR/R + SEED_DIR/assets  (run_infer.sh layout). The folder name is used as the seed label.
# DATA     : valid/{images,masks} (20), test/images (optional)
# Candidates (fixed in advance): lite20 | lite19p = lite20 - pairwise | lite18 = lite20 - pairwise - HRNet347.
# lite20 runs the full R+E+F; lite19p/lite18 rerun only R and reuse lite20's E probabilities and F (identical for all three).
# Set ALLOW_RETRAINED=1 for retrained weights (skips SHA checks). Finished steps are skipped on rerun.
set -euo pipefail
DATA=$(cd "$1" && pwd); OUT=$2; GPU=$3; shift 3
HERE=$(cd "$(dirname "$0")/.." && pwd); L=$HERE/Model349_fusion805_lite23_b4ws; PY=${PYTHON:-python}
EXTRA=(); FEX=(); [[ ${ALLOW_RETRAINED:-0} == 1 ]] && { EXTRA=(--allow-retrained); FEX=(--allow-retrained-refiner); }
mkdir -p "$OUT"; OUT=$(cd "$OUT" && pwd)
for SD in "$@"; do
  SD=$(cd "$SD" && pwd); name=$(basename "$SD"); W=$OUT/$name; mkdir -p "$W/logs"
  if [[ -d $SD/R/weights ]]; then RW=$SD/R/weights; else RW=$SD/R; fi; AS=$SD/assets
  [[ -d $RW && -d $AS ]] || { echo "$SD: need R weights and assets"; exit 2; }
  if [[ ! -e $W/parent ]]; then   # code-only copy of the parent package whose Model349_exh14/weights points at this seed
    mkdir -p "$W/parent"; (cd "$HERE/Model349_fusion805" && tar --exclude=./Model349_exh14/weights -cf - .) | (cd "$W/parent" && tar -xf -)
    ln -s "$RW" "$W/parent/Model349_exh14/weights"
  fi
  for split in valid test; do
    [[ -d $DATA/$split/images ]] || continue
    d=$W/lite20/$split
    if [[ ! -e $d/completion.json ]]; then rm -rf "$d"; mkdir -p "$W/lite20"
      echo "[$(date +%T)] $name lite20 $split"
      "$PY" "$L/infer_compact.py" --config "$L/selected_config_lite20.json" --parent-package "$W/parent" --assets "$AS" \
        --input "$DATA/$split/images" --output "$d" --gpus "$GPU" "${EXTRA[@]}" > "$W/logs/lite20_$split.log" 2>&1
    fi
    for v in lite19p lite18; do
      d=$W/$v/$split; [[ -e $d/fusion/predicted_labels ]] && [[ -e $d/done ]] && continue; rm -rf "$d"; mkdir -p "$d"
      echo "[$(date +%T)] $name $v $split"
      "$PY" "$W/parent/Model349_exh14/infer_lite.py" --input "$DATA/$split/images" --output "$d/release" \
        --config "$L/selected_R_$v.yaml" --gpus "$GPU" > "$W/logs/${v}_$split.log" 2>&1
      "$PY" "$W/parent/infer_fusion.py" --input "$DATA/$split/images" --release-labels "$d/release/predicted_labels" \
        --expert-probabilities "$W/lite20/$split/expert" --refiner "$AS/refiner/epoch8.pt" --output "$d/fusion" --device cpu \
        "${FEX[@]}" >> "$W/logs/${v}_$split.log" 2>&1
      touch "$d/done"
    done
  done
  if [[ -d $DATA/valid/masks ]]; then for v in lite20 lite19p lite18; do
    [[ -e $W/$v/valid_metrics.json ]] || bash "$HERE/score.sh" "$W/$v/valid/fusion/predicted_labels" "$DATA/valid/masks" "$W/$v/valid_metrics.json" > /dev/null
  done; fi
done
"$PY" "$HERE/seed_compare/summarize_seeds.py" "$OUT" | tee "$OUT/summary.txt"
