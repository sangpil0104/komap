"""Summarise run_seed_variants.sh: per-seed valid20 of each candidate, paired deltas vs lite20, test pixel changes.
   python seed_compare/summarize_seeds.py OUT"""
import json, sys
from pathlib import Path
import numpy as np
from PIL import Image
out = Path(sys.argv[1]); V = ['lite20', 'lite19p', 'lite18']; res = {}
def miou(p):
    d = json.loads(p.read_text()); return d['image_miou'] * 100, {x['image']: x['image_miou'] * 100 for x in d['images']}
for sd in sorted(p for p in out.iterdir() if (p / 'lite20').is_dir()):
    r = res[sd.name] = {}
    base = sd / 'lite20/valid_metrics.json'
    if base.exists():
        b, bi = miou(base); r['lite20'] = b
        for v in V[1:]:
            m = sd / v / 'valid_metrics.json'
            if m.exists():
                s, si = miou(m); d = [si[k] - bi[k] for k in bi]
                r[v] = s; r[v + '_delta'] = s - b; r[v + '_worst'] = min(d); r[v + '_better_worse'] = [sum(x > 1e-9 for x in d), sum(x < -1e-9 for x in d)]
    tb = sd / 'lite20/test/fusion/predicted_labels'
    for v in V[1:]:
        tv = sd / v / 'test/fusion/predicted_labels'
        if tb.exists() and tv.exists():
            c = n = 0
            for p in sorted(tb.glob('*.png')):
                x, y = np.asarray(Image.open(p)), np.asarray(Image.open(tv / p.name)); c += int((x != y).sum()); n += x.size
            r[v + '_test_changed'] = [c, n]
print(f"{'seed':16s}" + ''.join(f'{v:>11s}' for v in V) + '   d19p    d18   (valid20 %, delta %p vs lite20)')
for s, r in res.items():
    print(f'{s:16s}' + ''.join(f"{r.get(v, float('nan')):11.4f}" for v in V) + ''.join(f"{r.get(v + '_delta', float('nan')):+7.3f}" for v in V[1:]))
agg = {}
for v in V:
    xs = [r[v] for r in res.values() if v in r]
    if xs: agg[v] = {'n': len(xs), 'mean': float(np.mean(xs)), 'std': float(np.std(xs, ddof=1)) if len(xs) > 1 else None}
for v in V[1:]:
    ds = [r[v + '_delta'] for r in res.values() if v + '_delta' in r]
    if ds:
        agg[v].update({'delta_mean': float(np.mean(ds)), 'delta_std': float(np.std(ds, ddof=1)) if len(ds) > 1 else None,
                       'seeds_better': sum(d > 0 for d in ds), 'seeds_worse': sum(d < 0 for d in ds)})
for v, a in agg.items():
    line = f"{v:8s} seeds {a['n']}  mean {a['mean']:.4f}%" + (f"  std {a['std']:.4f}" if a['std'] is not None else '')
    if 'delta_mean' in a: line += f"  delta {a['delta_mean']:+.4f}%p" + (f" (std {a['delta_std']:.4f})" if a['delta_std'] is not None else '') + f"  better/worse seeds {a['seeds_better']}/{a['seeds_worse']}"
    print(line)
(out / 'summary.json').write_text(json.dumps({'per_seed': res, 'aggregate': agg}, indent=1) + '\n')
