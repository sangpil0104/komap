#!/usr/bin/env bash
# lite19a (19 weights): lite20 with restart61 as the only high-res checkpoint for every image (no brightness bands, no restart51).
#   bash run_infer_lite19a.sh WEIGHTS INPUT_IMAGES OUTPUT [GPU] [--allow-retrained]
exec bash "$(cd "$(dirname "$0")" && pwd)/run_infer_variant.sh" lite19a "$@"
